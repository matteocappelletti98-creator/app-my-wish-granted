// src/lib/blog.ts
export type Article = {
  id: string;
  title: string;
  content: string;
  imageDataUrl?: string;
  createdAt: string;
  poiSlug?: string; // collegamento opzionale ad un POI (solo my.explore)
};

const KEY = "blog.articles.v1";

export function getArticles(): Article[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; }
}
export function saveArticles(list: Article[]) {
  localStorage.setItem(KEY, JSON.stringify(list));
}
export function upsertArticle(a: Article) {
  const list = getArticles();
  const idx = list.findIndex(x => x.id === a.id);
  if (idx >= 0) list[idx] = a; else list.unshift(a);
  saveArticles(list);
}
export function deleteArticle(id: string) {
  saveArticles(getArticles().filter(a=>a.id!==id));
}
