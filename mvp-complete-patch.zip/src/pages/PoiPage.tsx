// src/pages/PoiPage.tsx
import { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { fetchPlacesFromSheet, Place } from "@/lib/sheet";
import { MY_CSV_URL } from "@/config";

export default function PoiPage() {
  const { slug } = useParams<{slug: string}>();
  const [all, setAll] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{ fetchPlacesFromSheet(MY_CSV_URL).then(setAll).finally(()=>setLoading(false)); }, []);
  const poi = useMemo(()=> all.find(p => p.slug === slug), [all, slug]);

  if (loading) return <div className="p-6">Caricamento…</div>;
  if (!poi) return <div className="p-6">POI non trovato. <Link className="text-blue-600 underline" to="/my">Torna a my.explore</Link></div>;

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold">{poi.name}</h1>
        <div className="text-sm text-gray-600">{poi.city}{poi.country ? `, ${poi.country}` : ""}</div>
      </div>

      <div className="rounded-2xl border h-72" id="poi-map"></div>

      <div>
        <h2 className="text-xl font-semibold mb-2">Descrizione</h2>
        <p className="text-gray-700 whitespace-pre-wrap">{poi.description}</p>
      </div>

      <div>
        <Link to="/blog" className="inline-block mt-3 px-3 py-2 rounded bg-blue-600 text-white">Collega articolo a questo POI</Link>
      </div>
    </div>
  );
}
