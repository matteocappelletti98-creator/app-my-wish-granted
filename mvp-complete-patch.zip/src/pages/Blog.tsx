// src/pages/Blog.tsx
import { useEffect, useState } from "react";
import { Article, getArticles, upsertArticle, deleteArticle } from "@/lib/blog";
import { fetchPlacesFromSheet, Place } from "@/lib/sheet";
import { MY_CSV_URL } from "@/config";

export default function Blog() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [editing, setEditing] = useState<Article | null>(null);
  const [myPlaces, setMyPlaces] = useState<Place[]>([]);

  useEffect(() => { setArticles(getArticles()); }, []);
  useEffect(() => { fetchPlacesFromSheet(MY_CSV_URL).then(setMyPlaces); }, []);

  const save = () => {
    if (!editing) return;
    const a = { ...editing, id: editing.id || genId(), createdAt: editing.createdAt || new Date().toISOString() };
    upsertArticle(a);
    setArticles(getArticles());
    setEditing(null);
  };

  const onFile = async (f: File) => {
    if (!f) return;
    const dataUrl = await fToDataUrl(f);
    setEditing(e => e ? { ...e, imageDataUrl: dataUrl } : e);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Blog</h1>
        <button className="px-3 py-2 rounded bg-blue-600 text-white" onClick={()=>setEditing({ id:"", title:"", content:"", createdAt:"" })}>
          Crea il tuo articolo
        </button>
      </div>

      {editing && (
        <div className="border rounded-xl p-4 space-y-3">
          <input className="border p-2 rounded w-full" placeholder="Titolo" value={editing.title} onChange={e=>setEditing({...editing, title:e.target.value})} />
          <textarea className="border p-2 rounded w-full min-h-[160px]" placeholder="Scrivi qui…" value={editing.content} onChange={e=>setEditing({...editing, content:e.target.value})} />
          <div className="flex items-center gap-3">
            <input type="file" accept="image/*" onChange={e=>onFile((e.target.files?.[0] as File))} />
            {editing.imageDataUrl && <img src={editing.imageDataUrl} alt="" className="h-16 rounded" />}
          </div>
          <div>
            <label className="text-sm text-gray-600">Collega a un POI (solo sezione my.explore)</label>
            <select className="border p-2 rounded w-full"
              value={editing.poiSlug || ""} onChange={e=>setEditing({...editing, poiSlug: e.target.value || undefined})}>
              <option value="">Nessun collegamento</option>
              {myPlaces.map(p => <option key={p.id} value={p.slug}>{p.name}</option>)}
            </select>
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-2 rounded bg-blue-600 text-white" onClick={save}>Salva</button>
            <button className="px-3 py-2 rounded border" onClick={()=>setEditing(null)}>Annulla</button>
          </div>
        </div>
      )}

      <div className="grid gap-4">
        {articles.map(a => (
          <div key={a.id} className="rounded-xl border p-4 space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{a.title}</h2>
              <div className="flex gap-2">
                <button className="text-blue-600 underline" onClick={()=>setEditing(a)}>Modifica</button>
                <button className="text-red-600 underline" onClick={()=>{ deleteArticle(a.id); setArticles(getArticles()); }}>Elimina</button>
              </div>
            </div>
            {a.imageDataUrl && <img src={a.imageDataUrl} alt="" className="w-full max-h-64 object-cover rounded" />}
            <p className="text-gray-700 whitespace-pre-wrap">{a.content}</p>
            {a.poiSlug && <div className="text-sm text-gray-600">Collegato a: <b>{a.poiSlug}</b></div>}
          </div>
        ))}
        {articles.length === 0 && <div className="text-gray-500">Nessun articolo ancora.</div>}
      </div>
    </div>
  );
}

function fToDataUrl(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

function genId() {
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,8);
}
