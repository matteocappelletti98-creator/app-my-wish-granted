// src/pages/MyExplore.tsx
import { useEffect, useMemo, useState } from "react";
import { fetchPlacesFromSheet, Place } from "@/lib/sheet";
import MapView from "@/components/MapView";
import { Link, useNavigate } from "react-router-dom";
import { MY_CSV_URL } from "@/config";

export default function MyExplore() {
  const [all, setAll] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("");

  useEffect(() => {
    fetchPlacesFromSheet(MY_CSV_URL).then(setAll).finally(()=>setLoading(false));
  }, []);

  const categories = useMemo(()=>Array.from(new Set(all.map(p => (p.category || "").trim()).filter(Boolean))), [all]);
  const list = useMemo(()=> (category ? all.filter(p => (p.category || "").trim() === category) : all), [all, category]);
  const navigate = useNavigate();

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">my.explore</h1>
        <Link to="/add-place" className="px-3 py-2 rounded bg-blue-600 text-white">+ Inserisci POI</Link>
      </div>

      <div className="flex gap-2 flex-wrap">
        <button className={`border px-3 py-1 rounded ${!category ? "bg-blue-50 border-blue-400" : ""}`} onClick={()=>setCategory("")}>Tutte</button>
        {categories.map(c => (
          <button key={c} className={`border px-3 py-1 rounded ${category===c ? "bg-blue-50 border-blue-400" : ""}`} onClick={()=>setCategory(c!)}>{c}</button>
        ))}
      </div>

      <MapView places={list} selectedCategory={category} onMarkerClick={(p)=>navigate(`/my/poi/${p.slug}`)} />

      <div className="grid gap-4 md:grid-cols-2">
        {list.map((p) => (
          <div key={p.id} className="rounded-xl border p-4 shadow-sm space-y-1">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{p.name}</h2>
              {p.category && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">{p.category}</span>}
            </div>
            <p className="text-sm text-gray-600 line-clamp-2">{p.description}</p>
            <button onClick={()=>navigate(`/my/poi/${p.slug}`)} className="text-blue-600 underline text-sm">Apri scheda</button>
          </div>
        ))}
      </div>

      {loading && <div className="text-gray-500">Caricamento…</div>}
    </div>
  );
}
