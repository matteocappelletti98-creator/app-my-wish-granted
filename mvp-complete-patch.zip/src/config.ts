// src/config.ts
// ⚠️ Sostituisci gli ID con i tuoi valori reali (ma così compila già).

// URL del CSV pubblicato della Home (formato export CSV, non /edit)
export const HOME_CSV_URL =
  "https://docs.google.com/spreadsheets/d/1nMlIV3DaG2dOeSQ6o19pPP5OlpHW-atXr1fixKUG3bo/export?format=csv&gid=2050593337";

// URL del CSV pubblicato della sezione "my.explore" (metti il tuo ID reale)
export const MY_CSV_URL =
  "https://docs.google.com/spreadsheets/d/ID_DEL_FOGLIO_MY/export?format=csv&gid=0";

// Configurazione del Google Form per l'inserimento dei POI
export const GOOGLE_FORM = {
  // Metti il tuo link /viewform del Google Form
  baseUrl:
    "https://docs.google.com/forms/d/e/1FAIpQLSfTDxGRpDNG1JdSwD-fGUgSe3XrT9mO8wE_J-8ISsFhLz2P_g/viewform",
  embedded: true,
  entries: {
    // ⚠️ Metti gli entry reali ottenuti dal link precompilato
    lat: "entry.111111111",
    lng: "entry.222222222",
    // source: "entry.333333333", // opzionale se nel form
  },
};

// Costruisce l'URL del form precompilato con lat/lng[/source]
export function buildFormUrl(lat?: number, lng?: number, source?: string) {
  const params = new URLSearchParams();
  if (lat != null) params.set(GOOGLE_FORM.entries.lat, String(lat));
  if (lng != null) params.set(GOOGLE_FORM.entries.lng, String(lng));
  // aggiungi source solo se esiste in entries
  if (source && (GOOGLE_FORM as any).entries.source) {
    params.set((GOOGLE_FORM as any).entries.source, source);
  }
  return `${GOOGLE_FORM.baseUrl}?${params.toString()}${
    GOOGLE_FORM.embedded ? "&embedded=true" : ""
  }`;
}
