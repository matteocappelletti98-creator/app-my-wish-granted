# MWG — Complete Patch (SIM/MVP)

Questo pacchetto aggiunge:
- `my.explore` (seconda mappa)
- `Blog` con articoli (localStorage) e collegamento ai POI
- Inserimento POI con mappa cliccabile → Google Form precompilato
- Nav con link a **my.explore** e **Blog**
- Config centralizzata (`src/config.ts`)

## Come applicare (GitHub o Lovable)

### Opzione A — GitHub Web
1. Vai al branch di lavoro (es. `feature/mvp-upgrade`).
2. Clicca **Add file → Upload files** e trascina **tutto il contenuto** di questa cartella nello stesso posto del repo (mantieni le cartelle `src/...`).
3. Commit.

### Opzione B — Lovable
1. Apri il progetto nel branch giusto.
2. Trascina **lo ZIP** sull’editor → conferma l’unzip. Se non unzip, estrai in locale e trascina i singoli file/cartelle.
3. Source Control → Commit & Push.

## Config necessaria

Apri `src/config.ts` e **sostituisci**:
- `MY_CSV_URL` con l’URL export CSV del foglio *my.explore* (`.../export?format=csv&gid=...`)
- `GOOGLE_FORM.baseUrl` con il tuo `.../viewform`
- `entries.lat` e `entries.lng` con gli **entry reali** ottenuti dal link precompilato
  - opzionale: `entries.source` (se hai un campo "contesto")

## Nota su MapView (OSM)
Se non hai già OSM, nella tua `src/components/MapView.tsx` usa il tile:
```ts
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap contributors",
  maxZoom: 20,
}).addTo(map);
```

## Build tip
- Nessuna dipendenza extra (niente `uuid`).
- Alias `@/*` richiesto in tsconfig (di solito già presente).
- Se build fallisce, verifica prima `src/config.ts` (stringhe valide).

Buon lavoro! 🚀
